---
name: "shorts-scope"
description: "Inspect short videos: frames, motion, OCR/text styles and evidence-grounded creator notes using ShortsScope CLI."
---

# ShortsScope

1. Resolve this skill directory from the actual SKILL.md path you read. Run `python3 <skill-dir>/scripts/run.py --help`; use the linked checkout and Python reported by `references/runtime.json` when installed. Continue only if the command succeeds. Read the checkout's README and `docs/EVIDENCE.md` when choosing options.
2. For a local video, call `extract VIDEO --out NEW_DIR` through that runner. Choose the interval, frame budget and resolution needed for the question. Read `manifest.json` and the images themselves; confirm selected timestamps and the endpoint before interpreting them.
3. When motion or text needs evidence, call `measure MANIFEST --out NEW_DIR` with a caller-selected motion ROI, optional `--ocr`, text ROI, supplied font candidates or local pose model. Read `evidence.json`; distinguish unknown tracking from stationary background, and candidate font matching from exact identity. Verify each referenced crop against its parent frame.
4. Use `analyze MANIFEST --out NEW_DIR` to prepare the image list, prompt and response schema without calling a model. Add matching `--evidence` and optionally `--select-frames` to inspect a few full images while retaining dense measurements. Use your current image tools to analyze those actual images and detail crops; save raw schema-matching JSON and validate it with `analyze MANIFEST --backend import --response RESPONSE --out NEW_DIR`. Invoke `--backend codex` only when the requested workflow explicitly needs that separately authenticated service.
5. If source evidence is insufficient, use a narrower extraction interval or larger frames and compare again. Keep screen direction separate from anatomical left/right, report missing feet instead of inventing gait, and treat OCR/boxes/pose as estimates. Return the validated result/report paths, observations with frame IDs, creative suggestions separately, and remaining unsupported conclusions. Finish only after output validation and source-image inspection; schema success alone is not factual correctness.

The runner exposes independent primitives, not a mandatory summarization pipeline. Extraction and measurement are local; this skill does not register cron jobs, change host configuration or generate a video.
